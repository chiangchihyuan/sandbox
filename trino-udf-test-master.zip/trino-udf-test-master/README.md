trino-udf-test
===

```shell
mvn clean package
```

udf jar path `trino-udf-test/target/original-udfs-0.0.1-SNAPSHOT.jar`