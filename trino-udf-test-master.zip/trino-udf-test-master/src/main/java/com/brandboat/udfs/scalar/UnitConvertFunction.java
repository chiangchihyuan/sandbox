package com.brandboat.udfs.scalar;

import io.airlift.slice.Slice;
import io.trino.spi.function.Description;
import io.trino.spi.function.ScalarFunction;
import io.trino.spi.function.SqlType;
import io.trino.spi.type.StandardTypes;
import java.util.HashMap;

import static io.airlift.slice.Slices.utf8Slice;

public class UnitConvertFunction
{
    private UnitConvertFunction() {}

    @Description("UnitConvertFunction")
    @ScalarFunction("unit_convert")
    @SqlType(StandardTypes.VARCHAR)
    public static Slice FullToHalf(@SqlType(StandardTypes.VARCHAR) Slice s){

        String origin = s.toStringUtf8();
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("0019","AHvnacaFTi");
        map.put("0028","AZvSBirdku");
        map.put("0037","BHjvTSYryZ");
        map.put("0046","BSMqzUVRhI");
        map.put("0055","BoxDwCkDWu");
        map.put("0064","CHdukvsvEt");
        map.put("0073","CVXpEBprdC");
        map.put("0082","CsIXXFEzxw");
        map.put("0091","DWhhlZXZoi");
        map.put("0107","DdgrAQKmjD");
        map.put("0116","EFUineXzbk");
        map.put("0134","EdlEeqgNdJ");
        map.put("0143","ErJUCIkYdx");
        map.put("0152","FMsihdJyMx");
        map.put("0161","FojNjLyXGq");
        map.put("0170","FvRgwLBYeV");
        map.put("0189","GUuxTGPzVo");
        map.put("0198","GxWrerAcAB");
        map.put("0204","HHKNxZFzld");
        map.put("0213","HmdcKHqFdd");
        map.put("0222","HuMimPVGSd");
        map.put("0231","IUiBJMWWMx");
        map.put("0240","IrmQkbVlws");
        map.put("0259","JGNKrhPNZT");
        map.put("0268","JacbbfkfRA");
        map.put("0277","JyxwJlnWTf");
        map.put("0286","KbcNOBUwtN");
        map.put("0295","KvvDneLTtf");
        map.put("0301","LJXgMNJgcC");
        map.put("0310","LikVvGSZTR");
        map.put("0329","MEvWkNYBzW");
        map.put("0338","MTtjKEFmsw");
        map.put("0347","MtoZlNrHvw");
        map.put("0356","NRvgnTaVZM");
        map.put("0365","NnizPlBhxI");
        map.put("0374","NqffTdseEl");
        map.put("0383","OVvGTJutnw");
        map.put("0392","OlzOPZYGYs");
        map.put("0408","PHKflGcxrl");
        map.put("0417","PcDXVJgHcQ");
        map.put("0426","PqYOfIClPd");
        map.put("0435","QKwbpIzYmN");
        map.put("0444","QskBneccHs");
        map.put("0453","RCbTgGwayd");
        map.put("0462","RTzNOlKOqf");
        map.put("0471","RqYkCAcSaq");
        map.put("0480","SJLaYTkrmS");
        map.put("0499","SiGALBJfWd");
        map.put("0505","TORKbFBKtO");
        map.put("0514","TcbMIeAATM");
        map.put("0523","UAjLtCvHwQ");
        map.put("0541","UKPOHNJRkW");
        map.put("0550","UlaCJdgwmK");
        map.put("0569","UytKdvCDnL");
        map.put("0578","VRdXKcXUJP");
        map.put("0587","VvYcVxcnqy");
        map.put("0596","WEGLzdUUCw");
        map.put("0611","WeXlEtUltZ");
        map.put("0620","XKeqjVxPgq");
        map.put("0648","XOOUyUlQzw");
        map.put("0657","XqKwqxSMCs");
        map.put("0666","YKrXOrpzBj");
        map.put("0675","YluBLgGszX");
        map.put("0684","ZKQCwRoJFv");
        map.put("0693","ZVqXKvJbIV");
        map.put("0709","ZtLoaUvxPM");
        map.put("0718","aLiJNEXQte");
        map.put("0727","aXKQvLLVcM");
        map.put("0736","aqDllHXRrk");
        map.put("0745","bPEitqUsco");
        map.put("0754","bePbJTASyH");
        map.put("0763","cGnrShbKkM");
        map.put("0772","ckbakhnIvq");
        map.put("0781","crBsWOjsSa");
        map.put("0790","dZIfYlPIiK");
        map.put("0806","dlBYjXmhPb");
        map.put("0824","eOxhEIXwZX");
        map.put("0833","eWenitxwWq");
        map.put("0842","fBSJUTxRKE");
        map.put("0851","fVCeBhoiSB");
        map.put("0860","fhQvImBUZD");
        map.put("0879","gMPlncbseC");
        map.put("0888","gaQBhZkCZx");
        map.put("0897","gwCozdHCBh");
        map.put("0903","hYuxCVlAao");
        map.put("0912","hsbyFZkRCh");
        map.put("0921","iHzIReECOb");
        map.put("0930","iYBXpqAiWc");
        map.put("0949","ilszqqKitQ");
        map.put("0958","jDvUhjusYz");
        map.put("0967","jZfvKVRCNf");
        map.put("0976","kJAEPsFBaz");
        map.put("0985","kdirjnpgtE");
        map.put("1003","ksSpKPwojJ");
        map.put("1012","lKntejQbdm");
        map.put("1021","lWafrOmUfS");
        map.put("1030","mCNsOKuKYc");
        map.put("1049","mZlxioVoRO");
        map.put("1058","miUTSPXGvD");
        map.put("1067","nICsZALFIc");
        map.put("1076","nWFfTDYJKl");
        map.put("1094","nytgmIgEtl");
        map.put("1100","oQPjSQEoGa");
        map.put("0302","ohOAsTqSAB");
        map.put("0303","pGDHEndzMb");
        map.put("0304","pkvGYrBeru");
        map.put("0305","qEKraHIaGZ");
        map.put("0306","qYgLMkzMFX");
        map.put("0307","qmbakusIEs");
        map.put("0308","qzSQwjeLPI");
        map.put("0312","raUCPrrxRW");
        map.put("0313","rqrtQcTJNv");
        map.put("0316","sYOeWEgDoF");
        map.put("0317","shQbGEANcq");
        map.put("0318","tDVlEmZeeK");
        map.put("0319","tjQgIJvHSQ");
        map.put("0322","tqvpkuTVgb");
        map.put("0323","uTgvkOGqtk");
        map.put("0324","unwVMQIbZk");
        map.put("0328","uwfpjZMfag");
        map.put("0331","vOfQvxiBmu");
        map.put("0333","vvdeRmvsys");
        map.put("0334","wJJXQhPueo");
        map.put("0335","wrFoiTrjzI");
        map.put("0343","wsNMJaEHaC");
        map.put("0345","xgjyDTETCc");
        map.put("0346","xhCNoOkCXE");
        map.put("0350","yHSriXbmpK");
        map.put("0360","yYCqXrfDqE");
        map.put("0362","zAsnfyWRtR");
        map.put("0368","zSQzpEJChW");
        map.put("0532","zsEJxxsjyz");

        if (map.get(origin) == null)
          return utf8Slice(origin);
        else
          return utf8Slice(map.get(origin));
      }
}
