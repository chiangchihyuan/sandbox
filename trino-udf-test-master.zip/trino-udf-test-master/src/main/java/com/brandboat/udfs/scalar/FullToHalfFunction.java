package com.brandboat.udfs.scalar;

import io.airlift.slice.Slice;
import io.trino.spi.function.Description;
import io.trino.spi.function.ScalarFunction;
import io.trino.spi.function.SqlType;
import io.trino.spi.type.StandardTypes;

import static io.airlift.slice.Slices.utf8Slice;

public class FullToHalfFunction
{
    private FullToHalfFunction() {}

    @Description("full_to_half in column")
    @ScalarFunction("full_to_half")
    @SqlType(StandardTypes.VARCHAR)
    public static Slice FullToHalf(@SqlType(StandardTypes.VARCHAR) Slice s){
        String origin = s.toStringUtf8();
        for(char c:origin.toCharArray()) {
          origin = origin.replaceAll("　", " ");
          if((int)c >= 65281 && (int)c <= 65374){
            origin = origin.replace(c, (char)(((int)c)-65248));
          }
        }
        return utf8Slice(origin);
      }
}
